export default function Home() {
  return <div>🌸 Kasuga AI 正在運作中！</div>;
}